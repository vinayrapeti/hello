package day2;

import java.util.Scanner;

public class loop2 {
	public static void main(String[] args) {
		Scanner src = new Scanner (System.in);
		int i=1;
		while(i<=10 ) {
			System.out.println("*");
			i++;
		}
	}

}
