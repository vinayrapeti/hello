package day2;

import java.util.Scanner;

public class Loop3 {
public static void main(String[] args) {
	Scanner src=new Scanner (System.in);
	int i=1;
	do {
		System.out.println("*");
		i++;
	}while(i<10)
}
}
