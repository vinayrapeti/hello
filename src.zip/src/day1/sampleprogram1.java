package day1;

import java.util.Scanner;

public class sampleprogram1 {
	public static void main(String[] args) {
	System.out.println("vinay");
	Scanner src = new Scanner(System.in);
	System.out.println("enter a value");
	int a = src.nextInt();
	System.out.println("the value of the a is: " +a);
	src.close();
	}
}
