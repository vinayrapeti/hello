package day1;

import java.util.Scanner;

public class nexted_if {
	public static void main(String[] args) {
	Scanner src = new Scanner(System.in);
	System.out.println("enter height :");
	double height = src.nextDouble();
	System.out.println("enter weight");
	double weight = src.nextDouble();
	double weight
	
	

}
